The Cinnamon engine uses LWJGL. LWJGL's license is bundled as LICENSE.

/**************************** Cinnamon License ****************************/

MIT License

Copyright (c) 2017 Christian Ramos

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

/**************************************************************************/

[DEMO]
Running "cinnamon-demo.jar" won't work; please use the batch file. For a list of console commands to use during the demo, type "help" in the console.

[Keyboard controls]
Left arrow: move left
Right arrow: move right
Up arrow: jump (no surface required)
Spacebar: fire projectile from selected game object towards cursor

[Mouse controls]
Left click: select object (or deselect if nothing selectable)
Right click: move View towards selected object
Scroll wheel: zoom in/out
Extra: move the cursor close to the window's edge

Note[1]: Too many projectiles will produce significant lag due to a bug causing bodies to continuously compute their physics.
